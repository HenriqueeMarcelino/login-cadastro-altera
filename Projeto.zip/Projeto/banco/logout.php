<?php

$_SESSION["loginErro"] = "Logout Realizado com sucesso!";
header("Location: ../index.php?logout=true");
